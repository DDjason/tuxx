<?php
echo exec('whoami');
echo "<br>";
echo shell_exec("id -a");  
?>
